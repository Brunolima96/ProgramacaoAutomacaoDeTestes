


function calcularTotal(ferramentas, comprar){
  
    if(ferramentas.length == 0 || comprar.length == 0){
  
        throw new Error("Ambas as listas precisam ter ao menos um item.")
    }
    else{
      var ferramentasEncontradas = []
     
        for(ferramenta in comprar){
            
          for(i in ferramentas){
            
              if(comprar[ferramenta] == ferramentas[i].nome){
       
                ferramentasEncontradas.push(ferramentas[i]) 
              
              }   
  
          }
  
        }
        if(ferramentasEncontradas.length > 0){
        var nomeFerramenta = []
        var somaFerramentas = 0;
        for(i in ferramentasEncontradas){
  
          
          nomeFerramenta.push(ferramentasEncontradas[i].nome)
  
         
          somaFerramentas += ferramentasEncontradas[i].preco
        
        }
      }
      else{
        throw new Error("Nenhuma ferramenta desejada encontrada.")
      }
        return `O valor a pagar pelas ferramentas (${nomeFerramenta.join(', ')}) é R$ ${somaFerramentas.toFixed(2)}`
    }
  
  
  }


module.exports = {
    calcularTotal
}